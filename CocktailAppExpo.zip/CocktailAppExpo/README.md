# Cocktail App 🍹

App per esplorare cocktail alcolici e analcolici, con quiz, filtri, pubblicità e interfaccia elegante.

## 🚀 Come eseguire il progetto

1. Installa Expo CLI:
```bash
npm install -g expo-cli
```

2. Avvia il progetto:
```bash
cd CocktailAppExpo
npm install
expo start
```

## 📦 Compilazione APK
```bash
npx eas login
npx eas build:configure
npx eas build --platform android
```

Il file `.apk` sarà scaricabile da un link fornito da Expo.

## 📱 Funzionalità
- Filtri per tipo e gusto
- Quiz per cocktail consigliati
- Cocktail con immagini e descrizioni
- Pubblicità integrate (AdMob)
- Splash screen personalizzato

