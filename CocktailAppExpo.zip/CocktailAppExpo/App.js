import React from "react";
import CocktailSelector from "./components/CocktailSelector";
export default function App() {
  return <CocktailSelector />;
}
